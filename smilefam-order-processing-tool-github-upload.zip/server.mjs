import { createServer } from "node:http";
import { readFile, writeFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL(".", import.meta.url));
const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || "0.0.0.0";
const processedPath = join(root, "processed-orders.json");

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
};

createServer(async (request, response) => {
  try {
    const requestUrl = new URL(request.url, `http://${request.headers.host}`);

    if (requestUrl.pathname === "/api/google-sheet") {
      await proxyGoogleSheet(requestUrl, response);
      return;
    }

    if (requestUrl.pathname === "/api/processed-orders") {
      await handleProcessedOrders(request, response);
      return;
    }

    const pathname = requestUrl.pathname === "/" ? "/index.html" : requestUrl.pathname;
    const filePath = normalize(join(root, decodeURIComponent(pathname)));
    if (!filePath.startsWith(normalize(root))) {
      response.writeHead(403);
      response.end("Forbidden");
      return;
    }

    const body = await readFile(filePath);
    response.writeHead(200, {
      "Content-Type": contentTypes[extname(filePath)] || "application/octet-stream",
      "Cache-Control": "no-store",
    });
    response.end(body);
  } catch (error) {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end(error.message);
  }
}).listen(port, host, () => {
  console.log(`Smilefam order tool: http://${host}:${port}/`);
});

async function proxyGoogleSheet(requestUrl, response) {
  const target = requestUrl.searchParams.get("url");
  if (!target) {
    response.writeHead(400);
    response.end("Missing url");
    return;
  }

  const targetUrl = new URL(target);
  if (targetUrl.hostname !== "docs.google.com") {
    response.writeHead(400);
    response.end("Only docs.google.com URLs are allowed");
    return;
  }

  const upstream = await fetch(targetUrl, { redirect: "follow" });
  const body = await upstream.text();
  response.writeHead(upstream.ok ? 200 : upstream.status, {
    "Content-Type": "text/csv; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(body);
}

async function handleProcessedOrders(request, response) {
  if (request.method === "GET") {
    response.writeHead(200, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    });
    response.end(JSON.stringify(await readProcessedOrders()));
    return;
  }

  if (request.method === "POST") {
    const body = await readRequestBody(request);
    const payload = JSON.parse(body || "{}");
    const current = await readProcessedOrders();
    const orders = Array.isArray(payload.orders) ? payload.orders : [];
    const byKey = new Map(current.orders.map((order) => [order.key, order]));
    const processedAt = new Date().toISOString();

    for (const order of orders) {
      if (!order?.key) continue;
      byKey.set(order.key, {
        key: order.key,
        orderRef: order.orderRef || "",
        date: order.date || "",
        customer: order.customer || "",
        tracking: order.tracking || "",
        processedAt,
      });
    }

    const next = { orders: [...byKey.values()].sort((a, b) => a.processedAt.localeCompare(b.processedAt)) };
    await writeFile(processedPath, JSON.stringify(next, null, 2), "utf8");
    response.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    response.end(JSON.stringify(next));
    return;
  }

  response.writeHead(405);
  response.end("Method not allowed");
}

async function readProcessedOrders() {
  try {
    const body = await readFile(processedPath, "utf8");
    const parsed = JSON.parse(body);
    return { orders: Array.isArray(parsed.orders) ? parsed.orders : [] };
  } catch {
    return { orders: [] };
  }
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        request.destroy();
        reject(new Error("Request body too large"));
      }
    });
    request.on("end", () => resolve(body));
    request.on("error", reject);
  });
}
